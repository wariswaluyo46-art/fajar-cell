import type { ProductCategory } from "@/types";

const FALLBACK_THUMBNAILS: Record<ProductCategory, string> = {
  "handphone-bekas": "/images/products/samsung-galaxy-s22-5g.jpg",
  "handphone-baru": "/images/products/samsung-galaxy-a55-5g.jpg",
  aksesoris: "/images/products/anker-20w-charger.jpg",
};

export function getFallbackThumbnail(category: ProductCategory): string {
  return FALLBACK_THUMBNAILS[category];
}

/**
 * Path publik lokal, diawali tepat satu "/".
 * "//host/file.jpg" dan "/\\host" ditolak agar tidak lolos sebagai URL eksternal.
 */
export function isLocalImagePath(value: string): boolean {
  return /^\/(?![/\\])/.test(value.trim());
}

export function isDataImageUrl(value: string): boolean {
  return /^data:image\//i.test(value.trim());
}

/** Direct link gambar dari luar; hanya protokol http(s) yang diterima. */
export function isRemoteImageUrl(value: string): boolean {
  const trimmed = value.trim();
  if (!/^https?:\/\//i.test(trimmed)) return false;

  try {
    const url = new URL(trimmed);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

export function isValidImageSource(value: string): boolean {
  return (
    isLocalImagePath(value) ||
    isDataImageUrl(value) ||
    isRemoteImageUrl(value)
  );
}

/**
 * next/image hanya dipakai untuk aset lokal. Data URL dan URL eksternal
 * dirender sebagai <img> agar admin bebas memakai direct link tanpa
 * menambahkan remotePatterns per host.
 */
export function requiresNativeImage(value: string): boolean {
  return isDataImageUrl(value) || isRemoteImageUrl(value);
}

/**
 * Daftar foto contoh yang tersedia di `public/images/products/`.
 * Dipakai sebagai saran (datalist) pada form admin, bukan daftar tertutup:
 * admin tetap bisa mengetik path lokal lain.
 */
export const PRODUCT_IMAGE_PATHS = [
  "/images/products/samsung-galaxy-s22-5g.jpg",
  "/images/products/samsung-galaxy-a55-5g.jpg",
  "/images/products/redmi-note-12.jpg",
  "/images/products/redmi-note-13-pro-5g.jpg",
  "/images/products/oppo-reno-8t.jpg",
  "/images/products/vivo-v27e.jpg",
  "/images/products/infinix-note-30.jpg",
  "/images/products/realme-c55.jpg",
  "/images/products/anker-20w-charger.jpg",
  "/images/products/baseus-bowie-e2.jpg",
  "/images/products/anker-powercore-10000.jpg",
] as const;

/** "/images/products/samsung-galaxy-s22-5g.jpg" -> "Samsung Galaxy S22 5g" */
export function productImageLabel(path: string): string {
  const file = path.split("/").pop() ?? path;
  const name = file.replace(/\.(jpe?g|png|webp|avif)$/i, "").replace(/-/g, " ");

  return name.replace(/\b\w/g, (character) => character.toUpperCase());
}
